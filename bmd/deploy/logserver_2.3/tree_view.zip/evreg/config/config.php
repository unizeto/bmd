<?

$DB_HOST = "127.0.0.1";
$DB_PORT = "5432";
$DB_LOGIN = "made";
$DB_PASSWORD = "12345678";
$DB_NAME = "logi";
$DB_LIBRARY = "postgres";
$VERIFIER = "/opt/bmd/bin/verify_logs";
$AUDITOR = "/opt/bmd/bin/audit_tree";

$menu['id'] = 0;
$menu['port'] = 2;
$menu['pid'] = 3;
$menu['begin'] = 5;
$menu['status'] = 12;
$menu['operation'] = 17;

?>