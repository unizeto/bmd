#ifndef WIN32
#include<cases.h>
#else
#include <bmd\libbmdsql\cases.h>
#endif

#include <bmd/common/global_types.h>			//  (ROL)
#include <bmd/libbmdpr/prlib-common/PR_OBJECT_IDENTIFIER.h>
#include <bmd/libbmderr/libbmderr.h>

/* @todo plik do usuniecia */
